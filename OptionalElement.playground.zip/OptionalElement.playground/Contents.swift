import Cocoa
//original array
var optionalElements = ["Ant", 1, "Bird", 2, nil, "Dog", 3, "Cat", 5] as [Any?]
print (optionalElements)

//filtered arrat
let filteredElements = optionalElements.compactMap ({ $0 })
print(filteredElements)

// animal names only array
let filteredOptionalElements = optionalElements.compactMap ({ $0 as? String})
print (filteredOptionalElements)

//numbers only array
let filteredOptionalIntigers = optionalElements.compactMap ({ $0 as? Int})
print (filteredOptionalIntigers)

//array of names printed n times
var bool = true
var myArray = ""
var numbers: Int
for name in filteredElements {
    if bool {
        bool = false
        myArray = name as! String
        
    }
    else
    {
        bool = true
        numbers = name  as! Int
        for _ in 1...numbers
        {
            print(myArray)
        }
    }
}


// put array in dictionarry
var myDictionary = [String:Int] ()
 myDictionary = Dictionary(uniqueKeysWithValues: zip(filteredOptionalElements, filteredOptionalIntigers))
    print(myDictionary)
